﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula_23_03_ManipulacaoString
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Lenght

            //variaveis
            String texto = "TESTE";
            int quantidade = texto.Length;
            String entrada;

            //declarando valores
            Console.WriteLine(texto);
            Console.WriteLine("Em mínusculo: {0}", texto.ToLower());
            Console.WriteLine("O nome possui {0} caracteres", quantidade);
            Console.WriteLine("Última letra do nome {0}", texto [quantidade - 1]);

            //entrada de variáveis
            Console.WriteLine("Digite algo: ");
            entrada = Console.ReadLine();

            //processando dados e saída
            Console.WriteLine("O que vc digitou tem {0} letras", entrada.Length);

            Console.WriteLine($"A primeira letra é {entrada[0]}");
            Console.WriteLine($"A última letra é {entrada[entrada.Length -1]}");


            //Substring
            Console.WriteLine("Os 4 primeiros caracteres: {0}", entrada.Substring(0, 4));
            Console.WriteLine("Os 4 últimos caracteres: {0}", entrada.Substring(entrada.Length - 4));

            //pegar a última palavra digitada.
            //acha onde está o espaço
            int localEspaco = entrada.LastIndexOf(' ');

            if (localEspaco == -1)
            {
                Console.WriteLine("Esta frase não possui espaço!!");
            }
            else
            {
                Console.WriteLine("A última palavra da frase é {0}", entrada.Substring(localEspaco + 1));
            }

            Console.ReadKey();
        }
    }
}
