﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula_13032023
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string produto;
            double quantidade;
            double valorEstoque;
            double precoProduto;

            Console.WriteLine("Nome do Produto: ");
            produto = Console.ReadLine();
            Console.WriteLine("Preco do Produto: ");
            precoProduto = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Quantidade de estoque: ");
            quantidade= Convert.ToDouble(Console.ReadLine());
            Console.WriteLine($"\nO produto {produto} possui {quantidade} unidades");
            valorEstoque = quantidade * precoProduto;
            Console.Write($"O valor do estoque é: {valorEstoque}");
            Console.ReadKey();
        }
    }
}
