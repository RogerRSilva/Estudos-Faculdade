﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NparImpar13032023
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Int32 num;

            Console.WriteLine("Insira um número: ");
            num = Convert.ToInt32(Console.ReadLine());

            if( num % 2 == 0 )
            {
                Console.WriteLine(num + " É um número par.");
            }
            else
            {
                Console.WriteLine(num + " É um número ímpar.");
            }
            Console.ReadKey(); 
        }
    }
}
