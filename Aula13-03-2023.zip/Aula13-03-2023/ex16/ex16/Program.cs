﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ex16
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //variaveis
            string nome;
            char sexo;
            float salario;

            //entrada de dados
            Console.WriteLine("Insira seu nome: ");
            nome = Console.ReadLine();
            Console.WriteLine("Insira seu sexo(M/F): ");
            sexo = char.Parse(Console.ReadLine());
            Console.WriteLine("Insira seu salário: ");
            salario = float.Parse(Console.ReadLine());

            //saida de dados
            Console.WriteLine($"Olá sr(a). {nome}, seu salário é:  {salario.ToString("C2")}.");
            //definindo condições e saída de dados
            if (sexo == 'M' || sexo == 'm') 
            {
                Console.WriteLine("Seu sexo é: Masculino");
            }
            else if (sexo.ToString().ToUpper() == "F")
            {
                Console.WriteLine("Seu sexo é: Feminino");
            }
            else
            {
                Console.WriteLine("Sexo informado está errado!!!");
            }
            Console.ReadKey();
        }
    }
}
