﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace aula_0203_EntradaDados
{
    internal class Program
    {

        static void Main(string[] args)
        {
            //variaveis
            String nome;
            Int32 idade;

            //entrada de dados
            Console.WriteLine("Qual seu nome: ");
            nome = Console.ReadLine();

            Console.WriteLine("Qual sua idade: ");
            idade = Convert.ToInt32(Console.ReadLine());

            //Saída de Dados

            if(idade <= 1 || idade >= 120)
            {
                Console.WriteLine("Idade inválida!");
            }
            else
            {
                Console.WriteLine("Nome: {0}, {1} anos.", nome, idade);
            }
            //Espera a próxima tecla
            Console.ReadKey();
        }
    }
}
